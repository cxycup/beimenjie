import sensor, image, time, pyb

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time=1000)
sensor.set_auto_whitebal(False)

uart = pyb.UART(2, 115200)

THRESHOLDS = [
    (30, 100, 15, 127, 15, 127),
    (30, 100, -64, -8, -32, 32),
    (30, 100, -20, 30, 20, 80)
]

CMD_TEMPLATE = "MOVE %d %d %d\n"

def get_dominant_color(img):
    max_pixels = 0
    color_id = 0
    stats = img.get_statistics(thresholds=THRESHOLDS)

    for i, stat in enumerate(stats):
        if stat.l_mean() > max_pixels:
            max_pixels = stat.l_mean()
            color_id = i + 1

    return color_id if max_pixels > 1000 else 0

def map_position(x, y):
    base_angle = int((x / img.width()) * 180)
    height_factor = max(0.3, 1.0 - (y / img.height()))
    shoulder_angle = int(30 + height_factor * 60)
    elbow_angle = int(150 - height_factor * 80)

    return base_angle, shoulder_angle, elbow_angle

while True:
    img = sensor.snapshot()

    color = get_dominant_color(img)

    if color != 0:

        blob = max(img.find_blobs([THRESHOLDS[color-1]],
                               pixels_threshold=500,
                               area_threshold=500),
                               key=lambda b: b.area(),
                               default=None)

        if blob:

            img.draw_rectangle(blob.rect(), color=(255, 0, 0))
            img.draw_cross(blob.cx(), blob.cy())


            base, shoulder, elbow = map_position(blob.cx(), blob.cy())


            uart.write(CMD_TEMPLATE % (base, shoulder, elbow, 180))
            pyb.LED(1).on()

    time.sleep_ms(50)
