#include <Servo.h>

Servo base_servo;
Servo elbow_servo;
Servo gripper_servo;

const int base_servo = 11;  
const int elbow_servo = 10; 
const int gripper_servo = 5;

int current_angles[4] = {90, 90 , 0}; 
int target_angles[4] = {90, 90, 0};

void setup() {
  Serial.begin(115200); // 硬件串口用于调试
  Serial1.begin(115200, SERIAL_8N1, 2, 3); // 软件串口(D2-RX, D3-TX)
  

  base_servo.attach(9);
  shoulder_servo.attach(10);
  elbow_servo.attach(11);
  gripper_servo.attach(12);
  
  move_home();
}

void loop() {

  if (Serial1.available()) {
    String command = Serial1.readStringUntil('\n');
    process_command(command);
  }
  
  smooth_move();
  delay(20);
}

void process_command(String cmd) {
  if (cmd.startsWith("MOVE")) {
    sscanf(cmd.c_str(), "MOVE %d %d %d %d", 
           &target_angles[0], 
           &target_angles[1],
           &target_angles[2],
           &target_angles[3]);
    
    Serial.print("New target: ");
    Serial.print(target_angles[0]);
    Serial.print(", ");
    Serial.print(target_angles[1]);
    Serial.print(", ");
    Serial.println(target_angles[2]);
  }
}

void smooth_move() {
  const int MAX_STEP = 5; 
  
  for (int i = 0; i < 4; i++) {
    int diff = target_angles[i] - current_angles[i];
    
    if (abs(diff) > 0) {
    
      int step = constrain(diff, -MAX_STEP, MAX_STEP);
      current_angles[i] += step;
      
      switch(i) {
        case 0: base_servo.write(current_angles[0]); break;
        case 1: shoulder_servo.write(current_angles[1]); break;
        case 2: elbow_servo.write(current_angles[2]); break;
        case 3: gripper_servo.write(current_angles[3]); break;
      }
    }
  }
}

void move_home() {
  for (int i = 0; i < 4; i++) {
    target_angles[i] = (i == 3) ? 0 : 90;
  }
  
  while (memcmp(current_angles, target_angles, sizeof(current_angles)) != 0) {
    smooth_move();
    delay(50);
  }
}